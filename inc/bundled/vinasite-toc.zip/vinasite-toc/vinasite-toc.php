<?php
/**
 * Plugin Name: Vinasite Mục Lục
 * Plugin URI: https://vinasite.com.vn/
 * Description: Tự tạo mục lục (table of contents) từ các tiêu đề trong bài viết/trang. Nhẹ, không phụ thuộc thư viện ngoài, cuộn mượt, thu gọn được, đánh số. Chèn tự động hoặc bằng shortcode [vinasite_toc]. Thương hiệu VinaSite 100%.
 * Version: 1.0.0
 * Author: Vinasite
 * Author URI: https://vinasite.com.vn/
 * License: GPLv2 or later
 * Text Domain: vinasite-toc
 */

if (!defined('ABSPATH')) {
    exit;
}

class Vinasite_TOC
{
    const OPT = 'vinasite_toc_options';
    /** Chỗ giữ tạm cho shortcode: filter the_content sẽ thay bằng mục lục thật. */
    const TOKEN = '<!--VINASITE_TOC-->';

    public function __construct()
    {
        add_shortcode('vinasite_toc', array($this, 'shortcode'));
        // Chạy SAU do_shortcode (ưu tiên 11) và wpautop (10) để đọc HTML đã hoàn chỉnh.
        add_filter('the_content', array($this, 'filter_content'), 20);
        add_action('wp_enqueue_scripts', array($this, 'assets'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    /* ---------------- Cấu hình ---------------- */

    public function defaults()
    {
        return array(
            'post_types'   => array('post'),
            'levels'       => array('h2', 'h3', 'h4'),
            'min_headings' => 3,
            'auto_insert'  => 1,
            'title'        => 'Mục lục',
            'numbered'     => 1,
            'collapsible'  => 1,
        );
    }

    public function opt($key)
    {
        $o = wp_parse_args((array) get_option(self::OPT, array()), $this->defaults());
        return isset($o[$key]) ? $o[$key] : null;
    }

    /* ---------------- Lõi: quét tiêu đề, gắn id, dựng mục lục ---------------- */

    /**
     * Trả về array(toc_html, content_da_gan_id) hoặc null nếu không đủ tiêu đề.
     */
    private function process($content)
    {
        $levels = (array) $this->opt('levels');
        if (empty($levels)) {
            return null;
        }
        $tags = implode('|', array_map(function ($l) {
            return preg_quote($l, '/');
        }, $levels));

        if (!preg_match_all('/<(' . $tags . ')\b([^>]*)>(.*?)<\/\1>/is', $content, $matches, PREG_SET_ORDER)) {
            return null;
        }

        $items = array();
        $used  = array();
        $new_content = $content;

        foreach ($matches as $h) {
            $tag   = strtolower($h[1]);
            $attrs = $h[2];
            $inner = $h[3];
            $text  = trim(wp_strip_all_tags($inner));
            if ($text === '') {
                continue;
            }

            // Đã có id thì dùng lại, chưa có thì tạo slug + gắn vào tiêu đề.
            if (preg_match('/\bid=["\']([^"\']+)["\']/i', $attrs, $idm)) {
                $id = $idm[1];
            } else {
                $id = $this->unique_slug($text, $used);
                $new_tag = '<' . $tag . $attrs . ' id="' . esc_attr($id) . '">' . $inner . '</' . $tag . '>';
                $new_content = $this->replace_first($h[0], $new_tag, $new_content);
            }
            $used[$id] = true;
            $items[]   = array('level' => (int) substr($tag, 1), 'id' => $id, 'text' => $text);
        }

        if (count($items) < (int) $this->opt('min_headings')) {
            return null;
        }
        return array($this->render($items), $new_content);
    }

    /** Slug không trùng (sanitize_title xử lý cả tiếng Việt có dấu). */
    private function unique_slug($text, $used)
    {
        $base = sanitize_title($text);
        if ($base === '') {
            $base = 'muc';
        }
        $slug = $base;
        $i = 2;
        while (isset($used[$slug])) {
            $slug = $base . '-' . $i;
            $i++;
        }
        return $slug;
    }

    /** Thay lần xuất hiện ĐẦU TIÊN của $search (không dùng regex). */
    private function replace_first($search, $replace, $subject)
    {
        $pos = strpos($subject, $search);
        if ($pos === false) {
            return $subject;
        }
        return substr_replace($subject, $replace, $pos, strlen($search));
    }

    /** Dựng HTML mục lục (danh sách lồng theo cấp tiêu đề). */
    private function render($items)
    {
        $numbered    = (int) $this->opt('numbered') ? ' vstoc--numbered' : '';
        $collapsible = (int) $this->opt('collapsible');
        $title       = (string) $this->opt('title');

        // Cấp nhỏ nhất để canh thụt lề tương đối.
        $min_level = min(array_map(function ($i) {
            return $i['level'];
        }, $items));

        $lis = '';
        foreach ($items as $it) {
            $depth = $it['level'] - $min_level; // 0,1,2...
            $lis .= '<li class="vstoc__item vstoc__item--l' . (int) $depth . '">'
                . '<a href="#' . esc_attr($it['id']) . '">' . esc_html($it['text']) . '</a></li>';
        }

        $out  = '<nav class="vstoc' . $numbered . '" role="navigation" aria-label="' . esc_attr($title) . '">';
        $out .= '<div class="vstoc__head">';
        $out .= '<span class="vstoc__title">' . esc_html($title) . '</span>';
        if ($collapsible) {
            $out .= '<button type="button" class="vstoc__toggle" aria-expanded="true">'
                . '<span class="vstoc__toggle-show">Ẩn</span><span class="vstoc__toggle-hide">Hiện</span></button>';
        }
        $out .= '</div>';
        $out .= '<ol class="vstoc__list">' . $lis . '</ol>';
        $out .= '</nav>';
        return $out;
    }

    /* ---------------- Chèn vào nội dung ---------------- */

    public function shortcode($atts)
    {
        // Chỉ trả token; filter_content sẽ thay bằng mục lục thật (sau khi đã có id).
        return self::TOKEN;
    }

    public function filter_content($content)
    {
        if (!is_singular() || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        if (!in_array(get_post_type(), (array) $this->opt('post_types'), true)) {
            return $content;
        }

        $has_token   = strpos($content, self::TOKEN) !== false;
        $auto_insert = (int) $this->opt('auto_insert');
        if (!$has_token && !$auto_insert) {
            return $content;
        }

        $res = $this->process($content);
        if (!$res) {
            // Không đủ tiêu đề: gỡ token nếu có để không lộ ra ngoài.
            return $has_token ? str_replace(self::TOKEN, '', $content) : $content;
        }
        list($toc, $content) = $res;

        if ($has_token) {
            return str_replace(self::TOKEN, $toc, $content);
        }

        // Tự chèn: đặt ngay TRƯỚC tiêu đề đầu tiên.
        $levels = (array) $this->opt('levels');
        $tags = implode('|', array_map(function ($l) {
            return preg_quote($l, '/');
        }, $levels));
        if (preg_match('/<(' . $tags . ')\b/i', $content, $m, PREG_OFFSET_CAPTURE)) {
            $pos = $m[0][1];
            return substr($content, 0, $pos) . $toc . substr($content, $pos);
        }
        return $toc . $content;
    }

    /* ---------------- CSS + JS (nội tuyến, nhẹ) ---------------- */

    public function assets()
    {
        if (is_admin()) {
            return;
        }
        $css = '.vstoc{background:#f7f9fc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 18px;margin:0 0 24px;font-size:15px;line-height:1.6}'
            . '.vstoc__head{display:flex;align-items:center;justify-content:space-between;gap:10px}'
            . '.vstoc__title{font-weight:700;color:#1e5aa8}'
            . '.vstoc__list{margin:10px 0 0;padding:0 0 0 4px;list-style:none;counter-reset:vstoc}'
            . '.vstoc__item{margin:4px 0}'
            . '.vstoc__list a{text-decoration:none;color:#22303f}'
            . '.vstoc__list a:hover{color:#1e5aa8;text-decoration:underline}'
            . '.vstoc__item--l1{padding-left:18px}.vstoc__item--l2{padding-left:36px}.vstoc__item--l3{padding-left:54px}'
            . '.vstoc--numbered .vstoc__item{counter-increment:vstoc}'
            . '.vstoc--numbered .vstoc__item>a::before{content:counter(vstoc) ". ";color:#1e5aa8;font-weight:600}'
            . '.vstoc.is-collapsed .vstoc__list{display:none}'
            . '.vstoc__toggle{background:none;border:0;color:#1e5aa8;cursor:pointer;font:inherit;padding:2px 6px}'
            . '.vstoc__toggle-hide{display:none}.vstoc.is-collapsed .vstoc__toggle-show{display:none}.vstoc.is-collapsed .vstoc__toggle-hide{display:inline}'
            . 'html{scroll-behavior:smooth}';
        // Đăng ký handle rỗng để đính CSS nội tuyến (không tải file ngoài).
        wp_register_style('vinasite-toc', false);
        wp_enqueue_style('vinasite-toc');
        wp_add_inline_style('vinasite-toc', $css);

        $js = '(function(){document.addEventListener("click",function(e){var b=e.target.closest(".vstoc__toggle");'
            . 'if(!b)return;var n=b.closest(".vstoc");if(!n)return;var c=n.classList.toggle("is-collapsed");'
            . 'b.setAttribute("aria-expanded", c?"false":"true");});})();';
        wp_register_script('vinasite-toc', false, array(), false, true);
        wp_enqueue_script('vinasite-toc');
        wp_add_inline_script('vinasite-toc', $js);
    }

    /* ---------------- Trang cài đặt ---------------- */

    public function admin_menu()
    {
        add_options_page('Vinasite Mục Lục', 'Vinasite Mục Lục', 'manage_options', 'vinasite-toc', array($this, 'settings_page'));
    }

    public function register_settings()
    {
        register_setting('vinasite_toc', self::OPT, array($this, 'sanitize'));
    }

    public function sanitize($in)
    {
        $d = $this->defaults();
        $all_pt = array_keys(get_post_types(array('public' => true)));
        $all_lv = array('h2', 'h3', 'h4', 'h5', 'h6');
        return array(
            'post_types'   => array_values(array_intersect((array) ($in['post_types'] ?? $d['post_types']), $all_pt)) ?: array('post'),
            'levels'       => array_values(array_intersect((array) ($in['levels'] ?? $d['levels']), $all_lv)) ?: array('h2', 'h3'),
            'min_headings' => max(1, min(20, (int) ($in['min_headings'] ?? $d['min_headings']))),
            'auto_insert'  => empty($in['auto_insert']) ? 0 : 1,
            'title'        => sanitize_text_field($in['title'] ?? $d['title']),
            'numbered'     => empty($in['numbered']) ? 0 : 1,
            'collapsible'  => empty($in['collapsible']) ? 0 : 1,
        );
    }

    public function settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $o = wp_parse_args((array) get_option(self::OPT, array()), $this->defaults());
        ?>
        <div class="wrap">
            <h1>Vinasite Mục Lục</h1>
            <p>Tự tạo mục lục từ tiêu đề trong bài viết. Chèn thủ công bằng shortcode <code>[vinasite_toc]</code>.</p>
            <form method="post" action="options.php">
                <?php settings_fields('vinasite_toc'); ?>
                <table class="form-table">
                    <tr><th>Áp dụng cho</th><td>
                        <?php foreach (get_post_types(array('public' => true), 'objects') as $pt) : ?>
                            <label style="margin-right:14px"><input type="checkbox" name="<?php echo esc_attr(self::OPT); ?>[post_types][]" value="<?php echo esc_attr($pt->name); ?>" <?php checked(in_array($pt->name, (array) $o['post_types'], true)); ?>> <?php echo esc_html($pt->labels->singular_name); ?></label>
                        <?php endforeach; ?>
                    </td></tr>
                    <tr><th>Cấp tiêu đề</th><td>
                        <?php foreach (array('h2', 'h3', 'h4', 'h5', 'h6') as $lv) : ?>
                            <label style="margin-right:14px"><input type="checkbox" name="<?php echo esc_attr(self::OPT); ?>[levels][]" value="<?php echo esc_attr($lv); ?>" <?php checked(in_array($lv, (array) $o['levels'], true)); ?>> <?php echo esc_html(strtoupper($lv)); ?></label>
                        <?php endforeach; ?>
                    </td></tr>
                    <tr><th>Số tiêu đề tối thiểu</th><td><input type="number" min="1" max="20" name="<?php echo esc_attr(self::OPT); ?>[min_headings]" value="<?php echo esc_attr($o['min_headings']); ?>" style="width:80px"> <span class="description">Ít hơn số này thì không hiện mục lục.</span></td></tr>
                    <tr><th>Tiêu đề hộp mục lục</th><td><input type="text" name="<?php echo esc_attr(self::OPT); ?>[title]" value="<?php echo esc_attr($o['title']); ?>" class="regular-text"></td></tr>
                    <tr><th>Tự động chèn</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT); ?>[auto_insert]" value="1" <?php checked($o['auto_insert'], 1); ?>> Tự chèn mục lục trước tiêu đề đầu tiên (nếu không dùng shortcode).</label></td></tr>
                    <tr><th>Đánh số</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT); ?>[numbered]" value="1" <?php checked($o['numbered'], 1); ?>> Hiển thị số thứ tự.</label></td></tr>
                    <tr><th>Thu gọn được</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT); ?>[collapsible]" value="1" <?php checked($o['collapsible'], 1); ?>> Cho phép Ẩn/Hiện mục lục.</label></td></tr>
                </table>
                <?php submit_button('Lưu cấu hình'); ?>
            </form>
        </div>
        <?php
    }
}

new Vinasite_TOC();
