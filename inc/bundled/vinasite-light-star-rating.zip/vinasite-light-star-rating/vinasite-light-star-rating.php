<?php
/**
 * Plugin Name: Vinasite Light Star Ratings
 * Plugin URI: https://vinasite.com.vn/
 * Description: Lightweight replacement for kk Star Ratings using the same shortcode, AJAX action, and post meta keys.
 * Version: 1.0.0
 * Author: Vinasite
 * Author URI: https://vinasite.com.vn/
 */

if (!defined('ABSPATH')) {
    exit;
}

const CODEX_LSR_META_PREFIX = '_kksr_';
const CODEX_LSR_NONCE_ACTION = 'wp_ajax_kk_star_ratings';

function codex_lsr_best() {
    return max(1, (int) get_option('kksr_stars', 5));
}

function codex_lsr_meta_key($key) {
    return CODEX_LSR_META_PREFIX . $key;
}

function codex_lsr_get_stats($post_id, $slug = 'default') {
    $post_id = (int) $post_id;
    $slug = sanitize_key($slug ?: 'default');

    $count = (int) get_post_meta($post_id, codex_lsr_meta_key('count_' . $slug), true);
    $ratings = (float) get_post_meta($post_id, codex_lsr_meta_key('ratings_' . $slug), true);

    if (!$count) {
        $count = (int) get_post_meta($post_id, codex_lsr_meta_key('casts'), true);
    }

    if (!$ratings) {
        $ratings = (float) get_post_meta($post_id, codex_lsr_meta_key('ratings'), true);
    }

    if (!$ratings && $count) {
        $avg = (float) get_post_meta($post_id, codex_lsr_meta_key('avg'), true);
        $ratings = $avg * $count;
    }

    $score = $count ? ($ratings / $count) : 0;

    return array(
        'count' => max(0, $count),
        'ratings' => max(0, $ratings),
        'score' => max(0, min(5, $score)),
    );
}

function codex_lsr_save_vote($post_id, $rating, $slug = 'default') {
    $post_id = (int) $post_id;
    $rating = max(1, min(5, (float) $rating));
    $slug = sanitize_key($slug ?: 'default');
    $stats = codex_lsr_get_stats($post_id, $slug);

    $count = $stats['count'] + 1;
    $ratings = $stats['ratings'] + $rating;
    $avg = $count ? ($ratings / $count) : 0;

    update_post_meta($post_id, codex_lsr_meta_key('casts'), $count);
    update_post_meta($post_id, codex_lsr_meta_key('avg'), $avg);
    update_post_meta($post_id, codex_lsr_meta_key('ratings'), $ratings);
    update_post_meta($post_id, codex_lsr_meta_key('count_' . $slug), $count);
    update_post_meta($post_id, codex_lsr_meta_key('avg_' . $slug), $avg);
    update_post_meta($post_id, codex_lsr_meta_key('ratings_' . $slug), $ratings);

    return codex_lsr_get_stats($post_id, $slug);
}

function codex_lsr_format_legend($score, $best, $count) {
    if (!$count) {
        return get_option('kksr_greet', 'Hãy là người đầu tiên đánh giá bài viết này.');
    }

    $legend = get_option('kksr_legend', '{score}/{best} - ({count} {votes})');
    $score_label = rtrim(rtrim(number_format((float) $score, 1, '.', ''), '0'), '.');

    return strtr($legend, array(
        '{score}' => $score_label,
        '{best}' => (string) $best,
        '{count}' => number_format_i18n((int) $count),
        '{votes}' => ((int) $count === 1 ? 'vote' : 'votes'),
        '{post}' => get_the_title(),
        '{type}' => get_post_type(),
    ));
}

function codex_lsr_render($attrs = array(), $content = '', $tag = 'kk-star-ratings') {
    $attrs = shortcode_atts(array(
        'id' => get_the_ID(),
        'slug' => 'default',
        'best' => codex_lsr_best(),
        'align' => '',
        'valign' => '',
        'readonly' => '',
        'legendonly' => '',
        'starsonly' => '',
        'class' => '',
        'reference' => 'shortcode',
    ), (array) $attrs, $tag);

    $post_id = (int) $attrs['id'];
    if (!$post_id) {
        return '';
    }

    $best = max(1, (int) $attrs['best']);
    $stats = codex_lsr_get_stats($post_id, $attrs['slug']);
    $score = $stats['score'];
    $display_score = min($best, ($score / 5) * $best);
    $percent = $best ? (($display_score / $best) * 100) : 0;
    $readonly = !empty($attrs['readonly']) || !is_singular();
    $classes = array('kk-star-ratings', 'codex-light-star-ratings');

    foreach (array('class', 'reference', 'align', 'valign') as $key) {
        if (!empty($attrs[$key])) {
            $classes[] = $key === 'class' ? sanitize_html_class($attrs[$key]) : 'kksr-' . sanitize_html_class($attrs[$key]);
        }
    }

    if ($readonly) {
        $classes[] = 'kksr-disabled';
    }

    $payload = array(
        'id' => $post_id,
        'slug' => sanitize_key($attrs['slug']),
        'best' => $best,
        'score' => $display_score,
        'count' => $stats['count'],
    );

    ob_start();
    ?>
    <div class="<?php echo esc_attr(implode(' ', array_filter($classes))); ?>" data-payload="<?php echo esc_attr(wp_json_encode($payload)); ?>">
        <?php if (empty($attrs['legendonly'])) : ?>
            <div class="kksr-stars" role="img" aria-label="<?php echo esc_attr(sprintf(__('Rated %1$s out of %2$s', 'codex-light-star-ratings'), round($display_score, 1), $best)); ?>">
                <div class="kksr-stars-empty"><?php echo esc_html(str_repeat('★', $best)); ?></div>
                <div class="kksr-stars-active" style="width: <?php echo esc_attr(round($percent, 3)); ?>%;"><?php echo esc_html(str_repeat('★', $best)); ?></div>
                <?php if (!$readonly) : ?>
                    <div class="kksr-star-buttons" aria-label="<?php esc_attr_e('Rate this post', 'codex-light-star-ratings'); ?>">
                        <?php for ($i = 1; $i <= $best; $i++) : ?>
                            <button type="button" class="kksr-star-button" data-rating="<?php echo esc_attr($i); ?>" aria-label="<?php echo esc_attr(sprintf(__('Rate %d stars', 'codex-light-star-ratings'), $i)); ?>"></button>
                        <?php endfor; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if (empty($attrs['starsonly'])) : ?>
            <div class="kksr-legend"><?php echo esc_html(codex_lsr_format_legend($display_score, $best, $stats['count'])); ?></div>
        <?php endif; ?>
    </div>
    <?php
    return trim(ob_get_clean());
}

function codex_lsr_auto_embed($content) {
    if (!is_singular('post') || !in_the_loop() || !is_main_query()) {
        return $content;
    }

    if (get_post_meta(get_the_ID(), codex_lsr_meta_key('disable'), true)) {
        return $content;
    }

    $position = get_option('kksr_position', 'bottom-left');
    $align = strpos($position, 'right') !== false ? 'right' : (strpos($position, 'center') !== false ? 'center' : 'left');
    $rating = codex_lsr_render(array('align' => $align, 'valign' => strpos($position, 'top-') === 0 ? 'top' : 'bottom', 'reference' => 'auto'));

    return strpos($position, 'top-') === 0 ? $rating . $content : $content . $rating;
}

function codex_lsr_ajax() {
    $payload = isset($_POST['payload']) && is_array($_POST['payload']) ? wp_unslash($_POST['payload']) : array();
    $post_id = isset($payload['id']) ? (int) $payload['id'] : 0;
    $best = isset($payload['best']) ? max(1, (int) $payload['best']) : codex_lsr_best();
    $rating = isset($_POST['rating']) ? (int) $_POST['rating'] : 0;
    $slug = isset($payload['slug']) ? sanitize_key($payload['slug']) : 'default';

    if (!check_ajax_referer(CODEX_LSR_NONCE_ACTION, 'nonce', false)) {
        wp_send_json_error(array('error' => 'Nonce is invalid.'), 403);
    }

    if (!$post_id || get_post_status($post_id) === false || $rating < 1 || $rating > $best) {
        wp_send_json_error(array('error' => 'Invalid rating.'), 400);
    }

    $cookie_name = 'codex_lsr_' . $post_id . '_' . $slug;
    if (!empty($_COOKIE[$cookie_name])) {
        wp_send_json_error(array('error' => 'You have already rated this post.'), 409);
    }

    $rating_out_of_5 = ($rating / $best) * 5;
    codex_lsr_save_vote($post_id, $rating_out_of_5, $slug);
    setcookie($cookie_name, '1', time() + YEAR_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true);

    wp_die(codex_lsr_render(array('id' => $post_id, 'slug' => $slug, 'best' => $best, 'reference' => 'ajax')), 201);
}

function codex_lsr_schema() {
    if (!is_singular()) {
        return;
    }

    $post_id = get_the_ID();
    $best = codex_lsr_best();
    $stats = codex_lsr_get_stats($post_id);
    if (!$stats['count'] || !$stats['score']) {
        return;
    }

    $rating_value = min($best, ($stats['score'] / 5) * $best);
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'CreativeWork',
        'name' => get_the_title($post_id),
        'aggregateRating' => array(
            '@type' => 'AggregateRating',
            'ratingValue' => round($rating_value, 2),
            'bestRating' => $best,
            'ratingCount' => (int) $stats['count'],
        ),
    );

    echo '<script type="application/ld+json" class="codex-lsr-schema">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}

function codex_lsr_should_load_assets() {
    if (is_singular('post')) {
        return true;
    }

    if (!is_singular()) {
        return false;
    }

    $post = get_post();
    return $post && (
        has_shortcode($post->post_content, 'kk-star-ratings')
        || has_shortcode($post->post_content, 'kkstarratings')
        || has_shortcode($post->post_content, 'kkratings')
    );
}

function codex_lsr_assets() {
    if (!codex_lsr_should_load_assets()) {
        return;
    }

    $ajax_url = admin_url('admin-ajax.php');
    $nonce = wp_create_nonce(CODEX_LSR_NONCE_ACTION);
    ?>
    <style id="codex-light-star-ratings-css">
    .codex-light-star-ratings{display:flex;align-items:center;gap:10px;margin:18px 0;color:#1f3448;font-size:16px;line-height:1.35}.codex-light-star-ratings.kksr-align-center{justify-content:center}.codex-light-star-ratings.kksr-align-right{justify-content:flex-end}.codex-light-star-ratings .kksr-stars{position:relative;display:inline-block;font-size:24px;line-height:1;color:#cbd5df;letter-spacing:2px}.codex-light-star-ratings .kksr-stars-active{position:absolute;inset:0 auto 0 0;overflow:hidden;color:#ffb400;white-space:nowrap;pointer-events:none}.codex-light-star-ratings .kksr-stars-empty{white-space:nowrap}.codex-light-star-ratings .kksr-star-buttons{position:absolute;inset:0;display:grid;grid-auto-flow:column;grid-auto-columns:1fr}.codex-light-star-ratings .kksr-star-button{appearance:none;border:0;background:transparent;cursor:pointer;padding:0;margin:0;min-width:22px}.codex-light-star-ratings .kksr-legend{font-size:15px;color:#516173}.codex-light-star-ratings.kksr-disabled .kksr-star-button{cursor:default}@media(max-width:849px){.codex-light-star-ratings{font-size:15px;gap:8px;flex-wrap:wrap}.codex-light-star-ratings .kksr-stars{font-size:22px}.codex-light-star-ratings .kksr-legend{font-size:14px}}
    </style>
    <script id="codex-light-star-ratings-js">
    window.CodexLightStarRatings={ajaxUrl:<?php echo wp_json_encode($ajax_url); ?>,nonce:<?php echo wp_json_encode($nonce); ?>};
    document.addEventListener('click',function(event){var button=event.target.closest('.codex-light-star-ratings .kksr-star-button');if(!button)return;var wrap=button.closest('.codex-light-star-ratings');if(!wrap||wrap.classList.contains('kksr-disabled'))return;var payload=JSON.parse(wrap.getAttribute('data-payload')||'{}');var body=new FormData();body.append('action','kk-star-ratings');body.append('nonce',window.CodexLightStarRatings.nonce);body.append('rating',button.getAttribute('data-rating'));Object.keys(payload).forEach(function(key){body.append('payload['+key+']',payload[key]);});wrap.classList.add('kksr-disabled');fetch(window.CodexLightStarRatings.ajaxUrl,{method:'POST',credentials:'same-origin',body:body}).then(function(res){return res.text();}).then(function(html){if(html&&html.charAt(0)!=='{'){wrap.outerHTML=html;}}).catch(function(){wrap.classList.remove('kksr-disabled');});});
    </script>
    <?php
}

add_shortcode('kk-star-ratings', 'codex_lsr_render');
add_shortcode('kkstarratings', 'codex_lsr_render');
add_shortcode('kkratings', 'codex_lsr_render');
add_filter('the_content', 'codex_lsr_auto_embed', 20);
add_action('wp_ajax_kk-star-ratings', 'codex_lsr_ajax');
add_action('wp_ajax_nopriv_kk-star-ratings', 'codex_lsr_ajax');
add_action('wp_head', 'codex_lsr_schema', 20);
add_action('wp_head', 'codex_lsr_assets', 80);

if (!function_exists('kk_star_ratings')) {
    function kk_star_ratings($idOrPostOrPayload = null) {
        if (is_numeric($idOrPostOrPayload)) {
            return codex_lsr_render(array('id' => (int) $idOrPostOrPayload, 'reference' => 'template'));
        }

        if (is_array($idOrPostOrPayload)) {
            $idOrPostOrPayload['reference'] = $idOrPostOrPayload['reference'] ?? 'template';
            return codex_lsr_render($idOrPostOrPayload);
        }

        if ($idOrPostOrPayload instanceof WP_Post) {
            return codex_lsr_render(array('id' => $idOrPostOrPayload->ID, 'reference' => 'template'));
        }

        return codex_lsr_render(array('reference' => 'template'));
    }
}
