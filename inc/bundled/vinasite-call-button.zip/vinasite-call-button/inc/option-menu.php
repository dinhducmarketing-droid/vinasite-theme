<div class="vinasite-call-setting">
    <h1 class="setting-title">CÀI ĐẶT NÚT GỌI · VINASITE</h1>
    <p>Được thiết kế và code bởi <a href="https://vinasite.com.vn" target="_blank">VinaSite Việt Nam</a></p>
    <hr>
    <div class="hoba-form">
        <form method="POST" action="options.php">
            <?php settings_fields('call-button-add-on'); ?>
            <div class="call-button-group">
                <div class="call-button-item">
                    <h2 class="button-title">Chat Messenger</h2>
                    <div class="call-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Bật/tắt</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_messenger" value="1" <?= (get_option('add_messenger') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Icon</th>
                                <td>
                                    <div class="call-item-icon"><img
                                                src="<?= plugins_url('../assets/images/icon-mess.svg', __FILE__) ?>" alt="">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Đường dẫn</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_messenger"
                                           placeholder="https://www.messenger.com/t/tenpage-cua-ban" value="<?= (!empty(get_option('url_messenger'))) ? get_option('url_messenger') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div><!--messenger-->
                <div class="call-button-item">
                    <h2 class="button-title">Gọi điện</h2>
                    <div class="call-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Bật/tắt</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_phone" value="1" <?= (get_option('add_phone') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Icon</th>
                                <td>
                                    <div class="call-item-icon"><img
                                                src="<?= plugins_url('../assets/images/icon-call.svg', __FILE__) ?>" alt="">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Điện thoại</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_phone"
                                           placeholder="0965565742" value="<?= (!empty(get_option('url_phone'))) ? get_option('url_phone') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div><!--phone-->
                <div class="call-button-item">
                    <h2 class="button-title">Email</h2>
                    <div class="call-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Bật/tắt</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_email" value="1" <?= (get_option('add_email') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Icon</th>
                                <td>
                                    <div class="call-item-icon"><img
                                                src="<?= plugins_url('../assets/images/icon-email.svg', __FILE__) ?>" alt="">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Email</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_email"
                                           placeholder="email@tenmien.com" value="<?= (!empty(get_option('url_email'))) ? get_option('url_email') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div><!--Email-->
                <div class="call-button-item">
                    <h2 class="button-title">Chat Zalo</h2>
                    <div class="call-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Bật/tắt</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_zalo" value="1" <?= (get_option('add_zalo') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Icon</th>
                                <td>
                                    <div class="call-item-icon"><img
                                                src="<?= plugins_url('../assets/images/icon-zalo.svg', __FILE__) ?>" alt="">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Điện thoại</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_zalo"
                                           placeholder="0965565742" value="<?= (!empty(get_option('url_zalo'))) ? get_option('url_zalo') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div><!--Zalo-->
                <div class="call-button-item">
                    <h2 class="button-title">Whatapp</h2>
                    <div class="call-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Bật/tắt</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_whatapp" value="1" <?= (get_option('add_whatapp') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Icon</th>
                                <td>
                                    <div class="call-item-icon"><img
                                                src="<?= plugins_url('../assets/images/whatapp_model.svg', __FILE__) ?>" alt="">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Điện thoại</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_whatapp"
                                           placeholder="https://www.messenger.com/t/0965565742" value="<?= (!empty(get_option('url_whatapp'))) ? get_option('url_whatapp') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div><!--Whatapp-->
                <div class="call-button-item">
                    <h2 class="button-title">Google map</h2>
                    <div class="call-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Bật/tắt</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_map" value="1" <?= (get_option('add_map') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Icon</th>
                                <td>
                                    <div class="call-item-icon"><img
                                                src="<?= plugins_url('../assets/images/widget_icon_map.svg', __FILE__) ?>" alt="">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Đường dẫn</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_map"
                                           placeholder="https://www.google.com/maps/@9.779349,105.6189045,11z?hl=vi-VN" value="<?= (!empty(get_option('url_map'))) ? get_option('url_map') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div><!--Map-->
            </div>
            <div class="call-button-group">
                <div class="setting-call">
                    <h2>Cài đặt trung</h2>
                    <div class="setting-body">
                        <table class="form-table">
                            <tbody>
                            <tr>
                                <th for="enable">Left/Right</th>
                                <td class="checkout-button">
                                    <label class="switch">
                                        <input type="checkbox"
                                               name="add_position" value="1" <?= (get_option('add_position') == 1) ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Left/Right</th>
                                <td>
                                    <input type="text" name="url_position"
                                           placeholder="30px" value="<?= (!empty(get_option('url_position'))) ? get_option('url_position') : '' ?>">
                                </td>
                            </tr>
                            <tr>
                                <th for="enable">Bottom</th>
                                <td class="checkout-button">
                                    <input type="text" name="url_bottom"
                                           placeholder="30px" value="<?= (!empty(get_option('url_position'))) ? get_option('url_position') : '' ?>">
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php submit_button(); ?>
        </form>
    </div>
</div>