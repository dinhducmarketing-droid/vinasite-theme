<?php
/*
 * Plugin Name: VinaSite Call Button
 * Author: VinaSite Việt Nam
 * Text Domain: vinasite-call
 * Description: Nút gọi / liên hệ nổi (gọi, Zalo, Messenger, email, WhatsApp, bản đồ).
 * Version:1.1.0
 * Plugin Uri: https://vinasite.com.vn
 */

define('VINASITE_CALL_URL', plugin_dir_path(__FILE__));

//add style theme
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('vinasite-call-button', plugins_url('assets/css/vinasite-call-button.css', __FILE__));
});

//wp admin style
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_style('call-button-admin-styles', plugins_url('assets/css/call-admin.css', __FILE__));
});

if (!class_exists('vinasite_call_button')) {
    class vinasite_call_button
    {
        function __construct()
        {
            if (!function_exists('add_shortcode')) {
                return;
            }

            //add submenu option page
            function add_submenu_options()
            {
                add_submenu_page(
                    'options-general.php',
                    'Cài đặt call button',
                    'Cài đặt call button',
                    'manage_options',
                    'vinasite-call-button',
                    'access_menu_options'
                );
            }

            //add field setup
            function access_menu_options()
            {
                require "inc/option-menu.php";
            }

            add_action('admin_menu', 'add_submenu_options');

            //xu ly luu data vao db
            function register_call_button_add_on()
            {
                //messenger
                register_setting('call-button-add-on', 'add_messenger');
                register_setting('call-button-add-on', 'url_messenger');
                //phone
                register_setting('call-button-add-on', 'add_phone');
                register_setting('call-button-add-on', 'url_phone');
                //email
                register_setting('call-button-add-on', 'add_email');
                register_setting('call-button-add-on', 'url_email');
                //zalo
                register_setting('call-button-add-on', 'add_zalo');
                register_setting('call-button-add-on', 'url_zalo');
                //whatapp
                register_setting('call-button-add-on', 'add_whatapp');
                register_setting('call-button-add-on', 'url_whatapp');
                //map
                register_setting('call-button-add-on', 'add_map');
                register_setting('call-button-add-on', 'url_map');
                //setting
                register_setting('call-button-add-on', 'add_position');
                register_setting('call-button-add-on', 'url_position');
                register_setting('call-button-add-on', 'url_bottom');
            }

            //register option buy admin
            add_action('admin_init', 'register_call_button_add_on');

            //add theme
            add_action('wp_footer', function () {
                ?>
                <div id="vinasite-call-bottom">
                    <div class="box-support" style=" bottom: <?= get_option('url_bottom') ?>">
                        <?php if (get_option('add_phone') == 1): ?>
                            <a href="tel:<?= get_option('url_phone') ?>" target="_blank"><img
                                        src="<?= plugins_url('/assets/images/icon-call.svg', __FILE__) ?>" alt="">
                                <span class="aml-text-content aml-tooltiptext">Gọi điện cho tôi</span>
                            </a>
                        <?php endif; ?>
                        <?php if (get_option('add_email') == 1): ?>
                            <a href="mailto:<?= get_option('url_email') ?>" target="_blank"><img
                                        src="<?= plugins_url('/assets/images/icon-email.svg', __FILE__) ?>" alt="">
                                <span class="aml-text-content aml-tooltiptext">Gửi tin nhắn</span>
                            </a>
                        <?php endif; ?>
                        <?php if (get_option('add_messenger') == 1): ?>
                            <a href="<?= get_option('url_messenger') ?>" target="_blank"><img
                                        src="<?= plugins_url('/assets/images/icon-mess.svg', __FILE__) ?>" alt="">
                                <span class="aml-text-content aml-tooltiptext">Facebook Messenger</span>
                            </a>
                        <?php endif; ?>
                        <?php if (get_option('add_zalo') == 1): ?>
                            <a href="https://zalo.me/<?= get_option('url_zalo') ?>" target="_blank"><img
                                        src="<?= plugins_url('/assets/images/icon-zalo.svg', __FILE__) ?>" alt="">
                                <span class="aml-text-content aml-tooltiptext">Chat Zalo</span>
                            </a>
                        <?php endif; ?>
                        <?php if (get_option('add_whatapp') == 1): ?>
                            <a href="https://wa.me/<?= get_option('url_whatapp') ?>" target="_blank"><img
                                        src="<?= plugins_url('/assets/images/whatapp_model.svg', __FILE__) ?>" alt="">
                                <span class="aml-text-content aml-tooltiptext">Chat WhatApp</span>
                            </a>
                        <?php endif; ?>
                        <?php if (get_option('add_map') == 1): ?>
                            <a href="<?= get_option('url_map') ?>" target="_blank"><img
                                        src="<?= plugins_url('/assets/images/widget_icon_map.svg', __FILE__) ?>" alt="">
                                <span class="aml-text-content aml-tooltiptext">Xem bản đồ</span>
                            </a>
                        <?php endif; ?>
                    </div>
                    <style>
                        <?php if(get_option('add_position')==1): ?>
                        .box-support {
                            right: <?=get_option('url_position'); ?>
                        }

                        <?php else:  ?>
                        .box-support {
                            left: <?=get_option('url_position'); ?>
                        }
                        <?php endif; ?>
                    </style>
                </div>
                <?php
            });
        }
    }

    function vinasite_call_button_shortcode()
    {
        global $mfpd;
        $mfpd = new vinasite_call_button();
    }

    add_action('plugins_loaded', 'vinasite_call_button_shortcode');
}