<?php
/**
 * Plugin Name: Vinasite Google Indexing
 * Description: Gửi URL lên Google Indexing API bằng service account. Tự động gửi index khi publish trang/bài + bulk submit. Ép IPv4 cho googleapis.com (server chặn IPv6 tới oauth2).
 * Version: 1.0
 * Author: Vinasite
 */

if (!defined('ABSPATH')) exit;

class Vinasite_Google_Indexing {
	const OPT_JSON  = 'vgi_service_account_json';
	const OPT_TYPES = 'vgi_post_types';
	const OPT_LOG   = 'vgi_log';
	const SCOPE     = 'https://www.googleapis.com/auth/indexing';
	// aud của JWT = endpoint token chuẩn của Google (Google validate theo giá trị này)
	const TOKEN_AUD = 'https://oauth2.googleapis.com/token';
	// NƠI POST lấy token: dùng www.googleapis.com vì oauth2.googleapis.com bị chặn IPv6 trên server này
	const TOKEN_URL = 'https://www.googleapis.com/oauth2/v4/token';
	const ENDPOINT  = 'https://indexing.googleapis.com/v3/urlNotifications:publish';

	public function __construct() {
		add_action('admin_menu', [$this, 'menu']);
		add_action('transition_post_status', [$this, 'on_transition'], 20, 3);
		add_action('admin_post_vgi_save', [$this, 'handle_save']);
		add_action('admin_post_vgi_test', [$this, 'handle_test']);
		add_action('admin_post_vgi_bulk', [$this, 'handle_bulk']);
	}

	/* ---------- wp_remote_post + tự thử lại khi timeout/kết nối lỗi ---------- */
	private function post_retry($url, $args, $tries = 3) {
		$args['timeout'] = 20;
		$resp = null;
		for ($i = 0; $i < $tries; $i++) {
			$resp = wp_remote_post($url, $args);
			if (!is_wp_error($resp)) return $resp;
			if ($i < $tries - 1) usleep(800000); // chờ 0.8s rồi thử lại
		}
		return $resp;
	}

	/* ---------- Auth: service account JWT -> access token ---------- */
	private function get_access_token() {
		$json = get_option(self::OPT_JSON);
		if (!$json) return new WP_Error('no_json', 'Chưa dán service account JSON');
		$sa = json_decode($json, true);
		if (!$sa || empty($sa['client_email']) || empty($sa['private_key']))
			return new WP_Error('bad_json', 'JSON không hợp lệ (thiếu client_email/private_key)');

		$cache = get_transient('vgi_token');
		if ($cache) return $cache;

		$now = time();
		$b64 = function ($d) { return rtrim(strtr(base64_encode($d), '+/', '-_'), '='); };
		$header = $b64(wp_json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
		$claim  = $b64(wp_json_encode([
			'iss'   => $sa['client_email'],
			'scope' => self::SCOPE,
			'aud'   => self::TOKEN_AUD,
			'exp'   => $now + 3600,
			'iat'   => $now,
		]));
		$signing_input = $header . '.' . $claim;
		$sig = '';
		if (!openssl_sign($signing_input, $sig, $sa['private_key'], 'SHA256'))
			return new WP_Error('sign', 'Ký JWT thất bại (private_key sai?)');
		$jwt = $signing_input . '.' . $b64($sig);

		$resp = $this->post_retry(self::TOKEN_URL, [
			'body' => [
				'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
				'assertion'  => $jwt,
			],
		]);
		if (is_wp_error($resp)) return $resp;
		$body = json_decode(wp_remote_retrieve_body($resp), true);
		if (empty($body['access_token']))
			return new WP_Error('token', 'Không lấy được token: ' . wp_remote_retrieve_body($resp));
		set_transient('vgi_token', $body['access_token'], 3300);
		return $body['access_token'];
	}

	/* ---------- Gửi 1 URL ---------- */
	public function submit_url($url, $type = 'URL_UPDATED') {
		$token = $this->get_access_token();
		if (is_wp_error($token)) { $this->log($url, 'ERR', $token->get_error_message()); return $token; }
		$resp = $this->post_retry(self::ENDPOINT, [
			'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
			'body'    => wp_json_encode(['url' => $url, 'type' => $type]),
		]);
		if (is_wp_error($resp)) { $this->log($url, 'ERR', $resp->get_error_message()); return $resp; }
		$code = wp_remote_retrieve_response_code($resp);
		$ok   = ($code == 200);
		$this->log($url, $ok ? 'OK' : 'ERR', $ok ? 'URL_UPDATED' : ($code . ' ' . wp_remote_retrieve_body($resp)));
		return $ok;
	}

	/* ---------- Tự động gửi khi publish / trash ---------- */
	public function on_transition($new, $old, $post) {
		if (wp_is_post_revision($post) || wp_is_post_autosave($post)) return;
		$types = (array) get_option(self::OPT_TYPES, ['page', 'post']);
		if (!in_array($post->post_type, $types, true)) return;
		if (!get_option(self::OPT_JSON)) return; // chưa cấu hình
		if ($new === 'publish') {
			// throttle: 1 lần/URL/giờ để đỡ tốn quota khi sửa liên tục
			$key = 'vgi_sent_' . $post->ID;
			if (get_transient($key)) return;
			set_transient($key, 1, HOUR_IN_SECONDS);
			$this->submit_url(get_permalink($post), 'URL_UPDATED');
		} elseif ($new === 'trash' && $old === 'publish') {
			$url = home_url('/' . preg_replace('/__trashed$/', '', $post->post_name) . '/');
			$this->submit_url($url, 'URL_DELETED');
		}
	}

	/* ---------- Log (giữ 100 dòng cuối) ---------- */
	private function log($url, $status, $msg) {
		$log = (array) get_option(self::OPT_LOG, []);
		array_unshift($log, [
			'time'   => current_time('Y-m-d H:i:s'),
			'url'    => $url,
			'status' => $status,
			'msg'    => mb_substr((string) $msg, 0, 200),
		]);
		update_option(self::OPT_LOG, array_slice($log, 0, 100), false);
	}

	/* ---------- Admin ---------- */
	public function menu() {
		add_management_page('Google Indexing', 'Google Indexing', 'manage_options', 'vgi', [$this, 'page']);
	}

	private function url($action) {
		return wp_nonce_url(admin_url('admin-post.php?action=' . $action), $action);
	}

	public function handle_save() {
		if (!current_user_can('manage_options')) wp_die('no');
		check_admin_referer('vgi_save');
		update_option(self::OPT_JSON, trim(wp_unslash($_POST['json'] ?? '')), false);
		$types = array_map('sanitize_text_field', (array) ($_POST['types'] ?? []));
		update_option(self::OPT_TYPES, $types ?: ['page', 'post'], false);
		delete_transient('vgi_token');
		wp_redirect(admin_url('tools.php?page=vgi&saved=1'));
		exit;
	}

	public function handle_test() {
		if (!current_user_can('manage_options')) wp_die('no');
		check_admin_referer('vgi_test');
		$t = $this->get_access_token();
		$ok = !is_wp_error($t);
		wp_redirect(admin_url('tools.php?page=vgi&test=' . ($ok ? 'ok' : urlencode($t->get_error_message()))));
		exit;
	}

	public function handle_bulk() {
		if (!current_user_can('manage_options')) wp_die('no');
		check_admin_referer('vgi_bulk');
		$what  = sanitize_text_field($_POST['what'] ?? 'page');
		$limit = min(190, max(1, (int) ($_POST['limit'] ?? 50)));
		$ids = get_posts([
			'post_type'      => $what,
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
			'no_found_rows'  => true,
		]);
		$ok = 0; $err = 0;
		foreach ($ids as $id) {
			$r = $this->submit_url(get_permalink($id), 'URL_UPDATED');
			if ($r === true) $ok++; else $err++;
		}
		wp_redirect(admin_url("tools.php?page=vgi&bulk={$ok}_{$err}"));
		exit;
	}

	public function page() {
		$json  = get_option(self::OPT_JSON);
		$types = (array) get_option(self::OPT_TYPES, ['page', 'post']);
		$log   = (array) get_option(self::OPT_LOG, []);
		$sa    = $json ? json_decode($json, true) : null;
		echo '<div class="wrap"><h1>Vinasite Google Indexing</h1>';

		if (isset($_GET['saved']))  echo '<div class="notice notice-success"><p>Đã lưu.</p></div>';
		if (isset($_GET['test']))   echo '<div class="notice notice-' . ($_GET['test']==='ok'?'success':'error') . '"><p>Test kết nối: ' . esc_html($_GET['test']==='ok'?'THÀNH CÔNG (lấy được access token)':$_GET['test']) . '</p></div>';
		if (isset($_GET['bulk']))   { list($o,$e)=array_pad(explode('_',$_GET['bulk']),2,0); echo '<div class="notice notice-success"><p>Bulk xong: '.intval($o).' OK, '.intval($e).' lỗi.</p></div>'; }

		echo '<p><b>Trạng thái:</b> ' . ($sa ? ('Đã cấu hình service account: <code>' . esc_html($sa['client_email'] ?? '?') . '</code>') : '<span style="color:#b32d2e">Chưa có service account JSON</span>') . '</p>';

		// Form lưu JSON + post types
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="vgi_save">';
		wp_nonce_field('vgi_save');
		echo '<h2>1. Service account JSON</h2><p>Dán toàn bộ nội dung file JSON tải từ Google Cloud:</p>';
		echo '<textarea name="json" rows="8" style="width:100%;font-family:monospace" placeholder=\'{"type":"service_account", ...}\'>' . esc_textarea($json) . '</textarea>';
		echo '<h2>2. Tự động gửi index khi publish</h2>';
		foreach (['page'=>'Trang (page)','post'=>'Bài viết (post)','recruit'=>'Tuyển dụng (recruit)','product'=>'Sản phẩm (product)','kho_mau'=>'Mẫu (kho_mau)'] as $pt=>$lbl) {
			echo '<label style="margin-right:16px"><input type="checkbox" name="types[]" value="' . esc_attr($pt) . '" ' . checked(in_array($pt,$types,true), true, false) . '> ' . esc_html($lbl) . '</label>';
		}
		echo '<p><button class="button button-primary">Lưu cấu hình</button></p></form>';

		// Test
		echo '<hr><h2>3. Test kết nối</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="vgi_test">';
		wp_nonce_field('vgi_test');
		echo '<button class="button">Test lấy access token</button></form>';

		// Bulk
		echo '<hr><h2>4. Gửi index hàng loạt</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="vgi_bulk">';
		wp_nonce_field('vgi_bulk');
		echo 'Gửi <select name="what"><option value="page">Trang (page)</option><option value="post">Bài viết (post)</option><option value="recruit">Tuyển dụng</option></select> ';
		echo 'mới nhất, số lượng <input type="number" name="limit" value="50" min="1" max="190" style="width:70px"> (tối đa 190/lần — quota Google 200/ngày) ';
		echo '<button class="button button-primary">Gửi ngay</button></form>';

		// Log
		echo '<hr><h2>Nhật ký (100 gần nhất)</h2><table class="widefat striped"><thead><tr><th>Thời gian</th><th>Trạng thái</th><th>URL</th><th>Chi tiết</th></tr></thead><tbody>';
		foreach ($log as $r) {
			$c = $r['status']==='OK' ? '#1a7f37' : '#b32d2e';
			echo '<tr><td>' . esc_html($r['time']) . '</td><td style="color:' . $c . ';font-weight:600">' . esc_html($r['status']) . '</td><td>' . esc_html($r['url']) . '</td><td><code>' . esc_html($r['msg']) . '</code></td></tr>';
		}
		if (!$log) echo '<tr><td colspan="4">Chưa có log.</td></tr>';
		echo '</tbody></table></div>';
	}
}
new Vinasite_Google_Indexing();
